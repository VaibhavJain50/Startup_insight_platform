import re
from typing import Dict, List, Any, Optional, Set
from langchain_google_genai import ChatGoogleGenerativeAI
import json
from dotenv import load_dotenv
load_dotenv()

def extract_company_info(files_data: Dict[str, Any]) -> Dict[str, Any]:
    """Extract basic company information from the files."""
    company_info = {
        "name": "Unknown",
        "stage": "Unknown",
        "sector": "Unknown",
        "funding_ask": "Unknown"
    }
    
    # Combine all text content for analysis
    all_content = ""
    for file_data in files_data.values():
        all_content += (file_data.get("content") or "") + "\n\n"
    
    # Initialize a basic model for extraction
    model = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)
    
    extraction_prompt = f"""
    Based on the following content from startup documents, extract the following information:
    1. Company name
    2. Stage (e.g. Seed, Series A, Series B, etc.)
    3. Sector/Industry
    4. Funding ask (how much they're seeking to raise)
    
    If you can't find a specific piece of information, respond with "Unknown" for that field.
    
    Content:
    {all_content[:10000]}  # Limit to first 10,000 chars
    
    Respond in JSON format like:
    {{
        "name": "Company Name",
        "stage": "Series A",
        "sector": "AI/Healthcare",
        "funding_ask": "$5 million"
    }}
    """
    
    try:
        response = model.invoke(extraction_prompt)
        # Extract JSON from response
        json_str = re.search(r'({.*})', response.content, re.DOTALL)
        if json_str:
            extracted_info = json.loads(json_str.group(1))
            # Update company_info with extracted data
            for key in company_info:
                if key in extracted_info and extracted_info[key] != "Unknown":
                    company_info[key] = extracted_info[key]
    except Exception as e:
        print(f"Error extracting company info: {e}")
    
    return company_info

async def extract_company_info_async(files_data: Dict[str, Any]) -> Dict[str, Any]:
    """Async: Extract basic company information from the files."""
    company_info = {
        "name": "Unknown",
        "stage": "Unknown",
        "sector": "Unknown",
        "funding_ask": "Unknown"
    }
    all_content = ""
    for file_data in files_data.values():
        all_content += (file_data.get("content") or "") + "\n\n"
    model = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)
    extraction_prompt = f"""
    Based on the following content from startup documents, extract the following information:
    1. Company name
    2. Stage (e.g. Seed, Series A, Series B, etc.)
    3. Sector/Industry
    4. Funding ask (how much they're seeking to raise)
    If you can't find a specific piece of information, respond with "Unknown" for that field.
    Content:
    {all_content[:10000]}
    Respond in JSON format like:
    {{
        "name": "Company Name",
        "stage": "Series A",
        "sector": "AI/Healthcare",
        "funding_ask": "$5 million"
    }}
    """
    try:
        response = await model.ainvoke(extraction_prompt)
        json_str = re.search(r'({.*})', response.content, re.DOTALL)
        if json_str:
            extracted_info = json.loads(json_str.group(1))
            for key in company_info:
                if key in extracted_info and extracted_info[key] != "Unknown":
                    company_info[key] = extracted_info[key]
    except Exception as e:
        print(f"Error extracting company info (async): {e}")
    return company_info