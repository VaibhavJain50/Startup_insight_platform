from dotenv import load_dotenv
load_dotenv()

from langchain.agents import AgentExecutor, create_react_agent, Tool
from langchain.prompts import PromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.tools import DuckDuckGoSearchRun
duckduckgo_tool = DuckDuckGoSearchRun()  

duck_tool = Tool(
    name="DuckDuckGoSearch",
    func=duckduckgo_tool.run,
    description="Use to search for general information about companies, funding, news, products, and market analysis."
)

tools = [duck_tool]

# ----------------------------
# 2. Define Custom ReAct Prompt
# ----------------------------
react_prompt = PromptTemplate.from_template("""
You are an AI assistant helping with **VC due diligence research**. 
You have access to the following tools:
{tools}

Tool Names: {tool_names}

---

### Guidelines:
- Break the problem into logical steps.
- If external information is required, call the right tool.
- Prefer **DuckDuckGoSearch** for company overview, funding history, products, market data, and news.
- Use stock tools only when financial/market data is explicitly requested.
- Gather and synthesize the results into a **structured due diligence report**.
- Include sources when possible.

---

### Required Report Format:
When you give the **Final Answer**, always include the following sections:

1. Company Overview (founding year, HQ, mission, team, structure)
2. Funding History (rounds, dates, amounts, investors, valuations)
3. Current Fundraising (target, round type, key terms, participants)
4. Business Model (revenue streams, monetization, unit economics if available)
5. Products & Services (offerings, roadmap, positioning)
6. Market Analysis (TAM/SAM/SOM, competitors, trends, growth drivers, challenges)
7. Legal, Regulatory & Governance (structure, board, policies, compliance)
8. Operational Metrics (CAC, CLTV, GMV, costs, KPIs if available)
9. Strategic Partnerships & Key Investors
10. Recent News & Public Statements

---

### ReAct Instructions:
You must reason step by step. Use this format:

Thought: describe what you want to do
Action: tool_name
Action Input: the input for the tool

Observation: result of the tool

{agent_scratchpad}

When you have enough information to answer:
Thought: I now know the final answer
Final Answer: Provide the structured due diligence report with all 10 sections filled as completely as possible.

---

### Task:
{input}

Begin!
""")


# ----------------------------
# 3. Build Agent & Executor
# ----------------------------
llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)

agent = create_react_agent(
    llm=llm,
    tools=tools,
    prompt=react_prompt
)

agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    handle_parsing_errors=True
)



