from langchain_community.tools.tavily_search import TavilySearchResults  # pip: tavily-python
# Ensure TAVILY_API_KEY is in your environment (.env already loaded)

from typing import Dict, List, Any, Optional, Set
from utils.custom_tools_agent import agent_executor
import time

def perform_financial_web_research_langchain(company_info: Dict[str, Any]) -> str:
    """
    Collect all publicly available financial data for a company suitable for a VC/investment due diligence report.
    Includes funding history, revenue, valuation, operational metrics, stock market data, and key KPIs.
    """

    name = company_info.get("name", "Unknown")
    sector = company_info.get("sector", "")

    # Optimized financial-specific queries
    financial_queries = [
        f"{name} annual revenue financial statements income statement balance sheet cash flow",
        f"{name} latest funding round valuation investors amount date",
        f"{name} competitors financial comparison market share",
        f"{name} ARR MRR gross margin unit economics",
        f"{name} CAC LTV churn retention operational metrics",
        f"{name} stock price market cap P/E ratio dividend EPS",
        f"{name} quarterly results earnings report press release",
        f"{name} analyst reports financial outlook",
        f"{name} debt equity liabilities assets",
        f"{name} strategic partnerships financial impact"
    ]

    # Increase k to cover more sources
    search = TavilySearchResults(k=20)
    results: List[Dict[str, Any]] = []

    for q in financial_queries:
        try:
            res = search.invoke(q) or []
            if isinstance(res, list):
                results.extend(res)
        except Exception:
            continue

    # Agent executor enrichment for structured financial data
    try:
        agent_context = agent_executor.run(
            f"Collect all publicly available, verifiable financial data for {name}, "
            f"including funding rounds, valuations, revenue, KPIs, stock performance, "
            f"and operational metrics. Provide URLs for each data point."
        )
        results.append({"title": "Agent Executor Output", "url": "", "content": agent_context})
    except Exception as e:
        results.append({"title": "Agent Executor Failed", "url": "", "content": str(e)})

    # Deduplicate by URL and content hash
    seen_urls, seen_hashes, deduped = set(), set(), []
    for r in results:
        url = r.get("url")
        content_hash = hash(r.get("content", "").strip())
        if (url and url in seen_urls) or (content_hash in seen_hashes):
            continue
        if url:
            seen_urls.add(url)
        seen_hashes.add(content_hash)
        deduped.append(r)
        if len(deduped) >= 15:  # Limit top 15 sources
            break

    if not deduped:
        return "No financial data found."

    # Format results in structured, readable output
    lines = []
    for r in deduped:
        title = r.get("title") or "Untitled"
        url = r.get("url") or ""
        snippet = r.get("content") or r.get("snippet") or ""
        lines.append(f"- {title} — {snippet} (Source: {url})")

    return "External Financial Context:\n" + "\n".join(lines)










def fetch_public_data(company_name: str) -> str:
    """
    Fetch comprehensive public data for a VC due diligence report using Tavily.
    """

    instruction = (
    f"Conduct a comprehensive collection of all publicly available, verifiable information for a VC due diligence report on {company_name}. "
    f"Include detailed data on the following areas: \n"
    f"1. Company overview: founding year, headquarters, mission, team, and organizational structure.\n"
    f"2. Funding history: all past funding rounds with dates, amounts, investors, and valuation at each round.\n"
    f"3. Current fundraising: target amount, round type, key terms, and investor participation.\n"
    f"4. Business model: revenue streams, monetization strategy, and unit economics.\n"
    f"5. Products & services: detailed offerings, product roadmap, and market positioning.\n"
    f"6. Market analysis: TAM/SAM/SOM, competitive landscape, key trends, growth drivers, and challenges.\n"
    f"7. Legal, regulatory & governance: corporate structure, board composition, key policies, and compliance issues.\n"
    f"8. Operational metrics: CAC, CLTV, GMV, fulfillment costs, and other relevant KPIs if publicly available.\n"
    f"9. Strategic partnerships and key investors.\n"
    f"10. Recent news, press releases, interviews, and public statements relevant to operations, strategy, or funding.\n"
)


    # Define detailed sub-queries
    topics = [
    "Executive Summary and Company Overview",
    "Founding Team and Key Personnel",
    "Business Model and Revenue Streams",
    "Products and Technology",
    "Market Analysis and Competitors",
    "Legal Structure, Governance, and Risks",
    "Recent News and Press Releases",
    "Funding History and Current Round",
    "Operational Metrics: CAC, CLTV, GMV, Fulfillment Costs",
    "Partnerships and Strategic Investors",
    "Stock Performance and Market Cap",
    ]

    queries = [f"{company_name} {topic}" for topic in topics]

    search = TavilySearchResults(k=10)
    results = []

    for q in queries:
        try:
            res = search.run(q)  # simpler query
            if res:
                results.append({"query": q, "result": res})
        except Exception as e:
            print(f"Error for query {q}: {e}")
        time.sleep(1)    

     # Add agent_executor enrichment
    try:
        agent_context=agent_executor.invoke({"input":instruction},config={"return_intermediate_steps": True})
       
        print("++++++++agent_context+++++++++")
        print(agent_context)
        print("+++++++++++++++++")
        results.append({"title": "Agent Executor Output", "url": "", "content": agent_context})
    except Exception as e:
        
        results.append({"title": "Agent Executor Failed", "url": "", "content": str(e)})   

    print("++++++++results+++++++++")
    print(results)
    print("+++++++++++++++++")     

    if not results:
        return "No external financial context found."

    # Just return raw results as string
    return str(results)
