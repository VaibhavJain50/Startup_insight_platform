# LangGraph imports
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph.message import add_messages

from utils.agent_state_utils import *
import json
import docx
from utils.tavily_websearch_utils import *
from typing import Dict, List, Any, Optional, Set
import asyncio
from utils.agents_utils import *

def synthesis_node(state: AgentState) -> AgentState:
    """Synthesis node in the graph."""
    new_state = state.model_copy()
    
    # Generate synthesis input
    synthesis_input = {
        "input": f"""
        # Synthesis Task
        
        ## Company Information:
        - Name: {new_state.company_info["name"]}
        - Stage: {new_state.company_info["stage"]}
        - Sector: {new_state.company_info["sector"]}
        - Funding Ask: {new_state.company_info["funding_ask"]}
        
        ## All Findings:
        {json.dumps(new_state.findings, indent=2)}
        
        ## Task:
        1. Integrate findings across all specialized agents
        2. Identify interdependencies between different evaluation areas
        3. Resolve any conflicting assessments
        4. Generate a holistic understanding of company strengths/weaknesses
        5. Prioritize findings based on investment criteria
        """,
        # For specialized agents only:
        "messages": new_state.messages[-3:] if len(new_state.messages) > 3 else new_state.messages
    }
    
    # Run the synthesis agent
    synthesis_output = synthesis_agent().invoke(synthesis_input)
    
    # Update state with synthesis message
    # add_messages(new_state, "synthesis", synthesis_output)

    new_state.messages.append(AIMessage(content=synthesis_output, name="synthesis"))
    
    # Add synthesis to findings and completed agents
    new_state.findings["synthesis"] = synthesis_output
    new_state.completed_agents.add("synthesis")
    
    # Move to reflection
    new_state.next_agent = "reflection"
    
    return new_state

async def reflection_node(state: AgentState) -> AgentState:
    """Reflection node in the graph."""
    new_state = state.model_copy()
    
    # Generate reflection input
    reflection_input = {
        "input": f"""
        # Reflection Task
        
        ## Company Information:
        - Name: {new_state.company_info["name"]}
        - Stage: {new_state.company_info["stage"]}
        - Sector: {new_state.company_info["sector"]}
        - Funding Ask: {new_state.company_info["funding_ask"]}
        
        ## Synthesis Output:
        {new_state.findings.get("synthesis", "No synthesis available.")}
        
        ## All Findings:
        {json.dumps(new_state.findings, indent=2)}
        
        ## Task:
        1. Critically examine analysis quality and completeness
        2. Identify potential blind spots or biases
        3. Challenge key assumptions
        4. Evaluate confidence levels for different findings
        5. Suggest additional areas for investigation
        """,
            # For specialized agents only:
        "messages": new_state.messages
    }
    
    # Run the reflection agent
    reflection_output = reflection_agent().invoke(reflection_input)
    
    
    # Update state with reflection message
    #add_messages(new_state, "reflection", reflection_output)
    new_state.messages.append(AIMessage(content=reflection_output, name="reflection"))
    
    # Add reflection to findings and completed agents
    new_state.findings["reflection"] = reflection_output
    new_state.completed_agents.add("reflection")
    
    # Move to investment thesis validation
    new_state.next_agent = "investment_thesis"
    
    return new_state

def investment_thesis_node(state: AgentState) -> AgentState:
    """Investment thesis validation node in the graph."""
    new_state = state.model_copy()
    
    # Generate investment thesis input with an explicit task
    investment_thesis_input = {
        "input": f"""
        # Investment Thesis Generation Task
        
        ## Company Information:
        - Name: {new_state.company_info["name"]}
        - Stage: {new_state.company_info["stage"]}
        - Sector: {new_state.company_info["sector"]}
        - Funding Ask: {new_state.company_info["funding_ask"]}
        
        ## Synthesis Output (Main Report):
        {new_state.findings.get("synthesis", "No synthesis available.")}
        
        ## Reflection Output (Bear Case / Devil's Advocate View):
        {new_state.findings.get("reflection", "No reflection available.")}
        
        ## All Detailed Findings:
        {json.dumps(new_state.findings, indent=2)}
        
        ---
        ## YOUR TASK:
        Based on all the information provided above (Synthesis, Reflection, and detailed findings), generate the final, comprehensive Investment Committee Memorandum.
        You MUST follow the strict structure and formatting guidelines provided in your system instructions.
        The final output should be a standalone, professional memo ready for the investment committee, starting with the "Executive Summary & Recommendation".
        """,
        "messages": new_state.messages
    }
    
    # Run the investment thesis agent
    investment_thesis_output = investment_thesis_agent().invoke(investment_thesis_input)
    
    # Update state with the final report
    new_state.messages.append(AIMessage(content=investment_thesis_output, name="investment_thesis"))
    new_state.findings["investment_thesis"] = investment_thesis_output
    new_state.completed_agents.add("investment_thesis")
    
    new_state.final_report = {
        "investment_recommendation": investment_thesis_output,
        "synthesis": new_state.findings.get("synthesis", ""),
        "reflection": new_state.findings.get("reflection", ""),
        "detailed_findings": new_state.findings
    }
    
    # End the workflow
    new_state.next_agent = None
    return new_state

# Router function for the graph
def router(state: AgentState) -> str:
    """Route to the next node based on the state."""
    if state["next_agent"] is None:
        return END
    return state["next_agent"]


# LangGraph Nodes: Function implementations for each node in the graph
def coordinator_node(state: AgentState) -> AgentState:
    """Coordinator node in the graph."""
    new_state = state.model_copy()#.copy()
    # print(state)
    # print("i am here")
    # Extract relevant information for the coordinator
    files_info = []
    # print(new_state)
    for file_name, file_data in new_state.files.items():
        files_info.append({
            "file_name": file_name,
            "file_type": file_data["file_type"],
            "size": file_data["size"]
        })
    
    # Generate coordinator input
    coordinator_input = {
        "input": f"""
        # Due Diligence Coordination Task
        
        ## Company Information:
        - Name: {new_state.company_info["name"]}
        - Stage: {new_state.company_info["stage"]}
        - Sector: {new_state.company_info["sector"]}
        - Funding Ask: {new_state.company_info["funding_ask"]}
        
        ## Available Files:
        {json.dumps(files_info, indent=2)}
        
        ## Categorized Files by Agent:
        {json.dumps(new_state.categorized_files, indent=2)}
        
        ## Task:
        1. Review the available files and their categorization
        2. Determine the priority of analysis and which agent should begin the investigation
        3. Provide initial guidance for the next agent in the process
        """,
        "messages": new_state.messages
    }
    # print("----")
    # print(coordinator_input)
    # print("going for shot")
    
    # Run the coordinator agent
    coordinator_output = coordinator_agent().invoke(coordinator_input)
    
    if "messages" not in new_state:
                new_state.messages = []
                
    # new_state.messages.append({
    #     "role": "coordinator",
    #     "content": coordinator_output
    # })

    new_state.messages.append(AIMessage(content=coordinator_output, name="coordinator"))

    # Update state with coordinator's message
    # add_messages(new_state, "coordinator", coordinator_output)
    
    # Determine next agent (simplified for this example)
    new_state.next_agent = "planning"
    # print(new_state)
    return new_state

async def planning_node(state: AgentState) -> AgentState:
    """Planning node in the graph."""
    new_state = state.model_copy()
    
    # Get files available to this agent
    agent_files = {}
    for file_name in new_state.categorized_files.get("planning", []):
        if file_name in new_state.files:
            agent_files[file_name] = new_state.files[file_name]
    
    # Generate planning input
    file_summaries = "\n".join([
        f"### {file_name} ({file_data['file_type']})\n{file_data['content'][:500]}...\n"
        for file_name, file_data in agent_files.items()
    ])
    
    planning_input = {
        "input": f"""
        # Due Diligence Planning Task
        
        ## Company Information:
        - Name: {new_state.company_info["name"]}
        - Stage: {new_state.company_info["stage"]}
        - Sector: {new_state.company_info["sector"]}
        - Funding Ask: {new_state.company_info["funding_ask"]}
        
        ## Available Files:
        {json.dumps(list(agent_files.keys()), indent=2)}
        
        ## File Content Previews:
        {file_summaries}
        
        ## Task:
        1. Review the available files and create a comprehensive due diligence plan
        2. Prioritize areas of analysis based on the initial information
        3. Identify any critical information gaps
        4. Recommend a sequence for the specialized agents
        """,
        "messages": new_state.messages
    }
    print("------>>>planning")
    # print(planning_input)
    # Run the planning agent
    planning_output = planning_agent().invoke(planning_input)

    # new_state.messages.append({
    #     "role": "planning",
    #     "content": planning_output
    # })

    new_state.messages.append(AIMessage(content=planning_output, name="planning"))
    # Update state with planning message
    # add_messages(new_state, "planning", planning_output)
    
    # Add planning to completed agents
    new_state.completed_agents.add("planning")
    
    # Do not route to a single specialized agent; parallel node handles fan-out
    new_state.next_agent = None
    print(f"taregting next agent {new_state.next_agent}")
    return new_state


async def specialized_agent_node(state: AgentState, agent_name: str) -> Dict[str, str]:
    """Async specialized agent node."""
    new_state = state.model_copy()

    # --- input prep (same as before, shortened here) ---
    agent_files = {
        f: new_state.files[f]
        for f in new_state.categorized_files.get(agent_name, [])
        if f in new_state.files
    }

    file_summaries = "\n".join([
        f"### {file_name} ({file_data['file_type']})\n{(file_data.get('content') or '')[:2000]}...\n"
        for file_name, file_data in agent_files.items()
    ])

    relevant_findings = {
        a: f for a, f in new_state.findings.items() if a != agent_name
    }

    external_research = ""
    if agent_name == "financial_analysis":
        try:
            external_research = perform_financial_web_research_langchain(new_state.company_info)
        except Exception:
            external_research = "External research unavailable due to an error."

        agent_input = {
        "input": f"""
    # {agent_name.replace('_', ' ').title()} Task
    ## Company: {new_state.company_info['name']}
    ## Files: {json.dumps(list(agent_files.keys()), indent=2)}
    ## File Content: {file_summaries}
    ## Previous Findings: {json.dumps(relevant_findings, indent=2) if relevant_findings else "None"}
    {("## External Research" + external_research) if external_research else ""}
    """,
        "messages": new_state.messages
    }

    # ✅ use async call here
    agent_output = await create_specialized_agent(agent_name).ainvoke(agent_input)

    return {
        "agent": agent_name,
        "output": agent_output,
    }


# ---- Parallel specialized fan-out node ----
from asyncio import Semaphore

async def parallel_specialized_node(state: AgentState) -> AgentState:
    """Run all specialized agents in parallel using asyncio."""
    new_state = state.model_copy()
    specialized_agents = [
        "financial_analysis", "legal_compliance", "market_strategy",
        "team_assessment", "technical_due_diligence", "customer_growth",
        "operational_due_diligence"
    ]

    # Concurrency limit to avoid overwhelming the provider
    concurrency_limit = 5
    semaphore = Semaphore(concurrency_limit)

    async def run_with_limit(agent: str):
        async with semaphore:
            return await specialized_agent_node(new_state, agent)

    # Run all async tasks concurrently with error capture
    tasks = [run_with_limit(agent) for agent in specialized_agents]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    

    # Merge results back into state
    for result in results:
        if isinstance(result, Exception):
            new_state.errors.append(str(result))
            continue
        agent = result["agent"]
        output = result["output"]
        new_state.findings[agent] = output
        new_state.completed_agents.add(agent)
        new_state.messages.append(AIMessage(content=output, name=agent))

    return new_state
