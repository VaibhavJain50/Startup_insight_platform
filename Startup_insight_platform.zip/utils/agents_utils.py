# Core imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
load_dotenv()

# importing prompts
from prompts.coordinator_agent import prompt as coordiantor_agent_prompt
from prompts.investment_thesis_agent import prompt as investment_thesis_agent_prompt
from prompts.planning_agent import prompt as planning_agent_prompt
from prompts.reflection_agent import prompt as reflection_agent_prompt
from prompts.specialized_agent import prompts as specialized_agent_prompts
from prompts.synthesis_agent import prompt as synthesis_agent_prompt

# Define agent functions
def create_agent_with_tools(agent_name: str, system_prompt: str):
    """Create an agent with tools based on the agent name and system prompt."""
    # Select the appropriate model based on agent assignments
    # model_name = MODEL_ASSIGNMENTS.get(agent_name, "gemini-1.5-flash-latest")

    # Use Google models for all agents
    model = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)

    # Create the prompt template
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content=system_prompt),
        MessagesPlaceholder(variable_name="messages"),
         ("human", "{input}")
        # HumanMessage(content="{input}")
    ])
    
    # Create the runnable
    runnable = (
        RunnablePassthrough.assign(messages=lambda x: x.get("messages", []))
        | prompt
        | model
        | StrOutputParser()
    )

    if agent_name == "financial_analysis":
        print(prompt)
        # print(runnable.invoke())
        # exit()
    
    return runnable

# Define the coordinator agent
def coordinator_agent():
    system_prompt = coordiantor_agent_prompt
    
    return create_agent_with_tools("coordinator", system_prompt)

# Define the planning agent
def planning_agent():
    system_prompt = planning_agent_prompt
    
    return create_agent_with_tools("planning", system_prompt)

# Define all specialized analysis agents
def create_specialized_agent(agent_name):
    # Define system prompts for each specialized agent
    agent_prompts = specialized_agent_prompts
    # if agent_name == "financial_analysis":
        
    if agent_name in agent_prompts:
        return create_agent_with_tools(agent_name, agent_prompts[agent_name])
    else:
        # Default generic prompt for any other agent
        return create_agent_with_tools(
            agent_name,
            f"You are the {agent_name.replace('_', ' ').title()} Agent in a VC due diligence system."
        )

# Define synthesis layer agents
def synthesis_agent():
    system_prompt = synthesis_agent_prompt
    return create_agent_with_tools("synthesis", system_prompt)




def reflection_agent():
    system_prompt = reflection_agent_prompt
    return create_agent_with_tools("reflection", system_prompt)




def investment_thesis_agent():
    system_prompt = investment_thesis_agent_prompt
    return create_agent_with_tools("investment_thesis", system_prompt)