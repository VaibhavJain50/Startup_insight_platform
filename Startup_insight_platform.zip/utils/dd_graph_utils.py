
from langgraph.graph import StateGraph, END
from utils.agent_state_utils import AgentState
from utils.langgraph_nodes_utils import planning_node,synthesis_node,reflection_node,coordinator_node,investment_thesis_node,specialized_agent_node,parallel_specialized_node


# Build the LangGraph
def build_due_diligence_graph():
    """Build and configure the LangGraph for the due diligence system."""
    # Initialize the graph
    workflow = StateGraph(AgentState)
    
    # Add nodes for each agent
    workflow.add_node("coordinator", coordinator_node)
    workflow.add_node("planning", planning_node)
    # Parallel fan-out node instead of individual specialized graph nodes
    workflow.add_node("parallel_specialized", parallel_specialized_node)
    
    # Add synthesis layer nodes
    workflow.add_node("synthesis", synthesis_node)
    workflow.add_node("reflection", reflection_node)
    workflow.add_node("investment_thesis", investment_thesis_node)
    
    # Set the entry point correctly
    workflow.set_entry_point("coordinator")
    
    # Add edges - starting with coordinator
    workflow.add_edge("coordinator", "planning")
    # Planning directly fans out to parallel specialized node
    workflow.add_edge("planning", "parallel_specialized")
    # After parallel specialized, go to synthesis
    workflow.add_edge("parallel_specialized", "synthesis")
    
    # Add conditional edges for synthesis layer
    workflow.add_conditional_edges(
        "synthesis",
        lambda state: state.next_agent if state.next_agent is not None else END,
    )
    
    workflow.add_conditional_edges(
        "reflection",
        lambda state: state.next_agent if state.next_agent is not None else END,
    )
    
    workflow.add_conditional_edges(
        "investment_thesis",
        lambda state: state.next_agent if state.next_agent is not None else END,
    )
    
    # Compile the graph
    return workflow.compile()