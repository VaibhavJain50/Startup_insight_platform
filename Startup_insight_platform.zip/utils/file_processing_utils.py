from unstructured.partition.auto import partition
import traceback
import os
import zipfile
import tempfile
from typing import Dict, List, Any, Optional, Set
from pathlib import Path
import json
import asyncio
from asyncio import Semaphore
import pandas as pd


from io import StringIO
import docx
import PyPDF2
import re

# File processing functions
def extract_text_from_file(file_path: str) -> str:
    """Extract text content from various file types."""
    file_ext = Path(file_path).suffix.lower()
    
    try:
        if file_ext == '.pdf':
            elements = partition(filename=file_path)
            text = ""
            for el in elements:
                t = (getattr(el, "text", None) or "")
                if t:
                    text += t + "\n"
            return text
            # with open(file_path, 'rb') as f:
            #     pdf_reader = PyPDF2.PdfReader(f)
            #     text = ""
            #     for page in pdf_reader.pages:
            #         text += page.extract_text() + "\n"
            #     return text
                
        elif file_ext == '.docx':
            doc = docx.Document(file_path)
            return "\n".join([para.text for para in doc.paragraphs])
            
        elif file_ext in ['.csv', '.xlsx', '.xls']:
            if file_ext == '.csv':
                df = pd.read_csv(file_path)
            else:
                df = pd.read_excel(file_path)
            buffer = StringIO()
            df.to_csv(buffer)
            return buffer.getvalue()
            
        elif file_ext in ['.txt', '.md']:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        
        else:
            # For other file types, just report the metadata
            file_info = Path(file_path)
            return f"File: {file_info.name}\nSize: {os.path.getsize(file_path)} bytes\nType: {file_ext}"
            
    except Exception as e:
        return f"Error processing file {file_path}: {str(e)}"

def process_uploaded_files(file_paths: List[str]) -> Dict[str, Any]:
    """Process uploaded files and extract their content."""
    files_data = {}
    
    for file_path in file_paths:
        try:
            # Handle zip files
            if file_path.lower().endswith('.zip'):
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    temp_dir = tempfile.mkdtemp()
                    zip_ref.extractall(temp_dir)
                    
                    # Process each file in the zip
                    for root, _, files in os.walk(temp_dir):
                        for file in files:
                            extracted_path = os.path.join(root, file)
                            if extracted_path.startswith('._'):
                                continue
                            file_content = extract_text_from_file(extracted_path)
                            if file_content is None:
                                file_content = ""
                            files_data[file] = {
                                "path": extracted_path,
                                "content": file_content,
                                "file_type": Path(file).suffix.lower(),
                                "size": os.path.getsize(extracted_path)
                            }
            else:
                # Process individual file
                file_content = extract_text_from_file(file_path)
                if file_content is None:
                    file_content = ""
                file_name = os.path.basename(file_path)
                files_data[file_name] = {
                    "path": file_path,
                    "content": file_content,
                    "file_type": Path(file_path).suffix.lower(),
                    "size": os.path.getsize(file_path)
                }
                
        except Exception as e:
            print(f"Error processing {file_path}: {str(e)}")
    
    return files_data