from utils.dd_graph_utils import build_due_diligence_graph
from langgraph.checkpoint.memory import MemorySaver
from typing import Dict, List, Set, Any, Optional
import pandas as pd
from io import StringIO
import docx
import PyPDF2
import re
import asyncio
from utils.agent_state_utils import AgentState
from utils.file_processing_utils import process_uploaded_files
from utils.categorize_files_utils import categorize_files_async
from utils.categorize_files_utils import categorize_files



class VCDueDiligenceSystem:
    """Multi-Agent Due Diligence System for VC Investment Evaluation."""
    
    def __init__(self):
        """Initialize the due diligence system."""
        self.graph = build_due_diligence_graph()
        self.state = None
        self.saver = MemorySaver()
    
    
    async def process_files_async(
    self,
    file_paths: List[str],
    user_id: str = "unknown_user",
    workspace_id: str = "unknown_workspace",
    message_id: Optional[str] = None,
    file_id:str="unknown_file_id"
    ) -> str:


        # Process uploaded files
        files_data = process_uploaded_files(file_paths)
        self.state = AgentState(files=files_data)
        print("--", self.state)

        # Categorize files (async)
        initial_state = await categorize_files_async(self.state)
        self.state = initial_state
        print(self.state)
        try:
            final_state = await self.graph.ainvoke(
                self.state,
                config={"recursion_limit": 100}

            )
        except Exception as e:
            import traceback
            print("[ERROR] Graph execution failed:")
            traceback.print_exc()
            raise


        self.state = final_state

        try:
            final_report = final_state.get("final_report")  # type: ignore[attr-defined]
        except AttributeError:
            final_report = None

        if final_report:
            return final_report.get("investment_recommendation", "") or "Failed to complete due diligence process"

        return "Failed to complete due diligence process"
    

    async def process_files(self, file_paths: List[str], analysis_type: str = "Full Due Diligence") -> tuple[str, dict, list]:
        """
        Run the due diligence pipeline and return:
        - report_str: markdown string of the report
        - files_data: dict of extracted file contents
        - executed_agents: list of agent names in (approx) execution order
        This implementation is defensive about the langgraph return types (AddableValuesDict / dict / object).
        """
        files_data = process_uploaded_files(file_paths)
        state = AgentState(files=files_data)

        # Pre-categorize files and extract company info to ensure context is available to the graph
        try:
            state = await categorize_files_async(state)
        except Exception:
            try:
                state = categorize_files(state)
            except Exception:
                pass

        workflow = build_due_diligence_graph()
        app = workflow.with_config({"recursion_limit": 50})

        # Run the workflow (blocking)
        final_state = await app.ainvoke(state)

        # Debugging / logging: print type and small summary of final_state for troubleshooting
        try:
            print("=== DEBUG: final_state type:", type(final_state))
            # If final_state behaves like a mapping, print keys
            if hasattr(final_state, "keys"):
                try:
                    print("=== DEBUG: final_state keys:", list(final_state.keys()))
                except Exception:
                    pass
            # If it has attributes, show some
            if hasattr(final_state, "__dict__"):
                print("=== DEBUG: final_state attrs:", list(vars(final_state).keys())[:50])
        except Exception:
            pass

        # Extract findings and final_report robustly
        findings = {}
        final_report = {}
        try:
            if hasattr(final_state, "get"):
                findings = final_state.get("findings") or getattr(final_state, "findings", {}) or {}
                final_report = final_state.get("final_report") or getattr(final_state, "final_report", {}) or {}
            else:
                findings = getattr(final_state, "findings", {}) or {}
                final_report = getattr(final_state, "final_report", {}) or {}
        except Exception:
            # last-resort attempts
            try:
                findings = final_state.findings
            except Exception:
                findings = {}
            try:
                final_report = final_state.final_report
            except Exception:
                final_report = {}

        # Build report text according to analysis_type
        if analysis_type == "Quick Assessment":
            synthesis_text = (findings or {}).get("synthesis", "No synthesis report was generated.")
            report_str = f"# Analysis Report (Quick Assessment)\n\n{synthesis_text}"
        elif analysis_type == "Financial Review":
            report_str = f"# Analysis Report (Financial Review)\n\n{(findings or {}).get('financial_analysis', 'No financial output was generated.')}"
        elif analysis_type == "Market Analysis":
            report_str = f"# Analysis Report (Market Analysis)\n\n{(findings or {}).get('market_strategy', 'No market output was generated.')}"
        elif analysis_type == "Team Evaluation":
            report_str = f"# Analysis Report (Team Evaluation)\n\n{(findings or {}).get('team_assessment', 'No team output was generated.')}"
        else:  # Full Due Diligence
            investment_reco = (final_report or {}).get("investment_recommendation", "No report generated.")
            report_str = f"# Analysis Report (Full Due Diligence)\n\n{investment_reco}"

        # --- Extract executed agents in order (best-effort) ---
        executed_agents = []

        # 1) Preferred: messages list (preserves order)
        try:
            msgs = None
            if hasattr(final_state, "get"):
                try:
                    msgs = final_state.get("messages")
                except Exception:
                    # fallback index access
                    try:
                        msgs = final_state["messages"]
                    except Exception:
                        msgs = None

            if msgs is None and hasattr(final_state, "messages"):
                msgs = getattr(final_state, "messages")

            if msgs:
                for m in msgs:
                    agent_name = None
                    # AIMessage-like objects often have .name attribute
                    if hasattr(m, "name"):
                        try:
                            agent_name = getattr(m, "name")
                        except Exception:
                            agent_name = None
                    # dict-like
                    if agent_name is None and isinstance(m, dict):
                        agent_name = m.get("name") or m.get("role") or m.get("agent")
                    # fallback to attribute 'role'
                    if agent_name is None and hasattr(m, "role"):
                        agent_name = getattr(m, "role")
                    if agent_name:
                        executed_agents.append(str(agent_name))
        except Exception:
            executed_agents = []

        # 2) Fallback: completed_agents (may be unordered set)
        if not executed_agents:
            try:
                ca = None
                if hasattr(final_state, "get"):
                    try:
                        ca = final_state.get("completed_agents")
                    except Exception:
                        try:
                            ca = final_state["completed_agents"]
                        except Exception:
                            ca = None
                if ca is None and hasattr(final_state, "completed_agents"):
                    ca = getattr(final_state, "completed_agents")
                if ca:
                    try:
                        executed_agents = list(ca)
                    except Exception:
                        executed_agents = [str(x) for x in ca]
            except Exception:
                executed_agents = []

        # Final defensive return
        try:
            return (report_str, files_data, executed_agents)
        except Exception:
            # last resort: return empty executed_agents
            return (report_str, files_data, [])


        
    def _extract_summary(self, report: str, sections: List[str]) -> str:
        """Extract specific sections from the full report."""
        extracted = []
        for section in sections:
            pattern = rf"(## {section}[\s\S]*?)(?=\n## |\Z)"
            match = re.search(pattern, report)
            if match:
                extracted.append(match.group(1).strip())
        return "\n\n".join(extracted) if extracted else "Summary not available."

    
    def get_findings_for_agent(self, agent_name: str) -> str:
        """Get findings for a specific agent."""
        if not self.state:
            return f"No findings available for agent {agent_name}"
        # Support both Pydantic model and mapping states
        try:
            findings = self.state.findings  # type: ignore[attr-defined]
        except AttributeError:
            findings = getattr(self.state, "get", lambda *_: None)("findings")  # mapping-like
        if findings and agent_name in findings:
            return findings[agent_name]
        return f"No findings available for agent {agent_name}"
    
    def get_full_report(self) -> Dict[str, Any]:
        """Get the full due diligence report with all findings."""
        if not self.state:
            return {"error": "No report available"}
        try:
            findings = self.state.findings  # type: ignore[attr-defined]
            final_report = self.state.final_report  # type: ignore[attr-defined]
        except AttributeError:
            findings = getattr(self.state, "get", lambda *_: None)("findings")
            final_report = getattr(self.state, "get", lambda *_: None)("final_report")
        if findings:
            return {
                "final_recommendation": (final_report or {}).get("investment_recommendation", ""),
                "synthesis": (findings or {}).get("synthesis", ""),
                "reflection": (findings or {}).get("reflection", ""),
                "agent_findings": findings or {}
            }
        return {"error": "No report available"}

    def process_files_sync(self, file_paths: List[str], analysis_type: str = "Full Due Diligence"):
        """Synchronous wrapper to run the async process_files method safely from non-async contexts."""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        if loop.is_running():
            new_loop = asyncio.new_event_loop()
            try:
                return new_loop.run_until_complete(self.process_files(file_paths, analysis_type))
            finally:
                new_loop.close()
        else:
            return loop.run_until_complete(self.process_files(file_paths, analysis_type))