from typing import Dict, List, Any, Optional, Set
from pydantic import BaseModel, Field

# Agent definitions and model assignments
AGENT_NAMES = [
    "coordinator",
    "planning",
    "financial_analysis",
    "legal_compliance",
    "market_strategy",
    "team_assessment",
    "technical_due_diligence",
    "customer_growth",
    "operational_due_diligence",
    "synthesis",
    "reflection",
    "investment_thesis"
]

class AgentState(BaseModel):
    """State for the multi-agent system."""
    files: Dict[str, Any] = Field(default_factory=dict)
    categorized_files: Dict[str, List[str]] = Field(default_factory=dict)
    findings: Dict[str, Any] = Field(default_factory=dict)
    current_analysis: Optional[Dict[str, Any]] = None
    messages: List[Dict[str, Any]] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
    next_agent: Optional[str] = None
    completed_agents: Set[str] = Field(default_factory=set)
    final_report: Dict[str, Any] = Field(default_factory=dict)
    company_info: Dict[str, Any] = Field(
        default_factory=lambda: {
            "name": "Unknown",
            "stage": "Unknown",
            "sector": "Unknown",
            "funding_ask": "Unknown"
        }
    )
    message_id: Optional[str] = None
    user_id: Optional[str] = None
    workspace_id: Optional[str] = None
    file_id: Optional[str]= None    
    




