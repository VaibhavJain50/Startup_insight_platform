from utils.agent_state_utils import *
# Core imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
load_dotenv()

import traceback
import os
import zipfile
import tempfile
from typing import Dict, List, Any, Optional, Set
from pathlib import Path
import json
import asyncio
from asyncio import Semaphore

from utils.extract_company_info_utils import extract_company_info
from utils.extract_company_info_utils import extract_company_info_async

# File tags mapping to agents
FILE_TAGS = {
    "financial": ["financial_analysis"],
    "legal": ["legal_compliance"],
    "market": ["market_strategy"],
    "team": ["team_assessment"],
    "technical": ["technical_due_diligence"],
    "customer": ["customer_growth"],
    "operations": ["operational_due_diligence"],
    "pitch": ["coordinator", "planning", "investment_thesis"],
    "general": AGENT_NAMES
}

# Agent System Functions
def categorize_files(state: AgentState) -> AgentState:
    """Categorize files based on content and match them to appropriate agents."""
    print(state)
    new_state = state.model_copy()
    # print(new_state.keys())
    # files = new_state.files
    files = new_state.files
    
    # Initialize model for file categorization
    categorizer = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)

    categorized_files = {agent: [] for agent in AGENT_NAMES}
    
    for file_name, file_data in files.items():
        print(file_name, len(file_data.get("content") or ""))
        # Create prompt for file categorization
        content_str = (file_data.get("content") or "")
        file_preview = content_str[:2000] + "..." if len(content_str) > 2000 else content_str
        
        categorization_prompt = f"""
        You are a file categorization specialist for a VC due diligence system.
        Based on the file content preview below, categorize this file into one or more of these tags:
        {', '.join(FILE_TAGS.keys())}
        
        File name: {file_name}
        File type: {file_data['file_type']}
        
        Content preview:
        {file_preview}
        
        Respond with ONLY a JSON array of appropriate tags. Example: ["financial", "general"]
        """
        
        # Get tags from AI
        response = categorizer.invoke(categorization_prompt)
        try:
            # Extract JSON array from response
            tags_str = response.content.strip()
            # Handle case where response includes extra text
            if not tags_str.startswith('['):
                tags_str = tags_str[tags_str.find('['):tags_str.rfind(']')+1]
            
            tags = json.loads(tags_str)
            
            # Map tags to agents
            for tag in tags:
                if tag in FILE_TAGS:
                    for agent in FILE_TAGS[tag]:
                        if file_name not in categorized_files[agent]:
                            categorized_files[agent].append(file_name)
        except Exception as e:
            print(traceback.format_exc())
            new_state.errors.append(f"Error categorizing {file_name}: {str(e)}")
            # new_state["errors"].append(f"Error categorizing {file_name}: {str(e)}")
            # If categorization fails, make file available to all agents
            for agent in AGENT_NAMES:
                categorized_files[agent].append(file_name)
    new_state.categorized_files = categorized_files
    # new_state.categorized_files = categorized_files
    
    # Extract company information
    new_state.company_info = extract_company_info(files)
    # new_state["company_info"] = extract_company_info(files)
    
    return new_state

async def categorize_files_async(state: AgentState) -> AgentState:
    """Async categorize files and extract company info using non-blocking calls."""
    new_state = state.model_copy()
    files = new_state.files
    categorizer = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0)
    categorized_files = {agent: [] for agent in AGENT_NAMES}

    async def categorize_one(file_name: str, file_data: Dict[str, Any]):
        content_str = (file_data.get("content") or "")
        file_preview = content_str[:2000] + "..." if len(content_str) > 2000 else content_str
        categorization_prompt = f"""
        You are a file categorization specialist for a VC due diligence system.
        Based on the file content preview below, categorize this file into one or more of these tags:
        {', '.join(FILE_TAGS.keys())}
        File name: {file_name}
        File type: {file_data['file_type']}
        Content preview:
        {file_preview}
        Respond with ONLY a JSON array of appropriate tags. Example: ["financial", "general"]
        """
        response = await categorizer.ainvoke(categorization_prompt)
        try:
            tags_str = response.content.strip()
            if not tags_str.startswith('['):
                tags_str = tags_str[tags_str.find('['):tags_str.rfind(']')+1]
            tags = json.loads(tags_str)
            for tag in tags:
                if tag in FILE_TAGS:
                    for agent in FILE_TAGS[tag]:
                        if file_name not in categorized_files[agent]:
                            categorized_files[agent].append(file_name)
        except Exception as e:
            new_state.errors.append(f"Error categorizing {file_name}: {str(e)}")
            for agent in AGENT_NAMES:
                categorized_files[agent].append(file_name)

    await asyncio.gather(*[categorize_one(fn, fd) for fn, fd in files.items()])
    new_state.categorized_files = categorized_files
    new_state.company_info = await extract_company_info_async(files)
    return new_state